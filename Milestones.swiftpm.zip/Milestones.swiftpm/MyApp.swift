import SwiftData
import SwiftUI
import TipKit

//
// Swift Student Challenge 2024
// Submission by Simon Hohenwarter
//

@main
struct MyApp: App {
    var container: ModelContainer
    
    init() {
        do {
            let schema = Schema([Milestone.self])
            let config = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
            container = try ModelContainer(for: schema, configurations: config)
        } catch {
            fatalError("Failed to configure SwiftData container.")
        }
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
                .task {
                    try? Tips.configure([
                        .datastoreLocation(.applicationDefault)
                    ])
                }
        }
        .modelContainer(container)
    }
}

