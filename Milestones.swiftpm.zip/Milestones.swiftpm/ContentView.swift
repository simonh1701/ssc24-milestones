import SwiftUI

struct ContentView: View {
    @State private var selection: AppScreen? = nil
    @AppStorage("hasNotFinishedOnboarding") private var hasNotFinishedOnboarding: Bool = true
    
    var body: some View {
        NavigationSplitView {
            AppSidebarList(selection: $selection)
        } detail: {
            AppDetailColumn(screen: selection)
        }
        .navigationSplitViewStyle(.prominentDetail)
        .sheet(isPresented: $hasNotFinishedOnboarding, onDismiss: {
            hasNotFinishedOnboarding = false
        }, content: {
            OnboardingView()
                .interactiveDismissDisabled()
                .navigationBarTitleDisplayMode(.inline)
        })
    }
}
