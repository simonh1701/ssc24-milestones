import SwiftUI

struct AppSidebarList: View {
    @Binding var selection: AppScreen?
    @State private var showingAboutSwiftStudentChallengeView = false
    
    var body: some View {
        List(selection: $selection) { 
            CalloutView(
                headerText: "What this app is about.", 
                markdownText: "Milestones is an app that lets you keep track of the little and big achievments in your life. It is designed to help people with ***imposter syndrome***."
            )
            .padding(.top, 10)
            .padding(.bottom, 10)
            
            Section { 
                NavigationLink(value: AppScreen.home) {
                    AppScreen.home.label
                }
            }
            
            Section {
                NavigationLink(value: AppScreen.milestoneOverview) {
                    AppScreen.milestoneOverview.label
                }
                
                NavigationLink(value: AppScreen.shareMilestone) {
                    AppScreen.shareMilestone.label
                }
            } header: {
                Text("My Milestones")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }
        }
        .listStyle(.sidebar)
        .navigationTitle("Milestones")
        .toolbar {
            Button {
                showingAboutSwiftStudentChallengeView.toggle()
            } label: {
                Image(systemName: "swift")
                    .resizable()
                    .scaledToFit()
                    .padding(8)
                    .background {
                        Color.accentColor
                            .cornerRadius(.infinity)
                            .opacity(0.15)
                    }
            }
        }
        .sheet(isPresented: $showingAboutSwiftStudentChallengeView) {
            NavigationStack { 
                AboutSwiftStudentChallengeView()
                    .navigationBarTitleDisplayMode(.inline)
            }
        }
    }
}

#Preview {
    NavigationSplitView {
        AppSidebarList(selection: .constant(nil))
    } detail: {
        Text("Nothing to see here!")
    }
}
