import SwiftUI

struct AppDetailColumn: View {
    var screen: AppScreen?
    
    var body: some View {
        Group {
            if let screen {
                screen.destination
            } else {
                ContentUnavailableView {
                    Label(
                        title: { 
                            Text("Welcome to Milestones!") 
                        },
                        icon: { 
                            Image("milestone")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80)
                        }
                    )
                } description: {
                    Text("Select a tab to get started.")
                }
            }
        }
    }
}

#Preview {
    AppDetailColumn()
}
