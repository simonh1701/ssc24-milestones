import SwiftUI

enum AppScreen: Codable, Hashable, Identifiable, CaseIterable {
    case home
    case milestoneOverview
    case shareMilestone
    
    var id: AppScreen { self }
}

extension AppScreen {
    @ViewBuilder
    var label: some View {
        switch self {
        case .home:
            Label("Home", systemImage: "doc.text.image")
        case .milestoneOverview:
            Label("Overview", systemImage: "suit.diamond.fill")
        case .shareMilestone:
            Label("Share", systemImage: "trophy")
        }
    }
    
    @ViewBuilder
    var destination: some View {
        switch self {
        case .home:
            HomeNavigationStack()
        case .milestoneOverview:
            MilestoneNavigationStack()
        case .shareMilestone:
            ShareMilestoneView()
        }
    }
}
