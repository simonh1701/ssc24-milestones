import SwiftUI

struct OnboardingView: View {
    @Environment(\.modelContext) var modelContext
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack {
            VStack(spacing: 4) {
                Image("milestones-icon")
                    .resizable()
                    .frame(width: 80, height: 80)
                    .padding(.bottom, 8)
                
                Text("Milestones")
                    .font(.system(.title, weight: .heavy))
                    .multilineTextAlignment(.center)
                
                Text("Milestones is an app intended to *help people with imposter syndrome and self-doubt*.")
                    .font(.system(.subheadline, weight: .medium))
                    .frame(width: 280)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
            }
            .fixedSize(horizontal: false, vertical: true)
            .padding(.bottom, 20)
            
            ScrollView {
                VStack(spacing: 20) {
                    VStack {
                        Text("Why I built this app and what it offers.")
                            .font(.system(.headline, weight: .medium))
                            .multilineTextAlignment(.center)
                        
                        Text("For me, to mitigate the feeling of being an imposter, I need something, anything to build and work towards. And what matters is not how fast I am working towards that but that I simply just do, because failing is better than never trying. With this app, I would like to share my approach to deal with my self-doubt and to enable other people to try it out for themselves. Here is the functionality the app offers:")
                            .font(.system(.subheadline, weight: .medium))
                            .multilineTextAlignment(.center)
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Image(systemName: "heart.text.square.fill")
                            .foregroundColor(.accentColor)
                            .font(.system(.title, weight: .regular))
                            .frame(width: 60, height: 50)
                        
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Learn what imposter syndrome is")
                                .font(.system(.footnote, weight: .semibold))
                            
                            Text("Get started by learning what imposter syndrome is, if it affects you, and what can be done to better deal with it. You can also figure out what type of imposter syndrome you may have.")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }
                        .fixedSize(horizontal: false, vertical: true)
                        
                        Spacer()
                    }
                    
                    HStack {
                        Image(systemName: "calendar")
                            .foregroundColor(.accentColor)
                            .font(.system(.title, weight: .regular))
                            .frame(width: 60, height: 50)
                        
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Plan and keep track of your milestones throughout the year.")
                                .font(.system(.footnote, weight: .semibold))
                            
                            Text("Milestones are the things you want to work on. In this app, milestones aren't things you want to reach eventually, milestones are specific things you do to reach your goals. You can plan when you want to work on a certain milestone and in an overview you can keep track of past, present and future milestones.")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }
                        .fixedSize(horizontal: false, vertical: true)
                        
                        Spacer()
                    }
                    
                    HStack {
                        Image(systemName: "pencil.and.list.clipboard")
                            .foregroundColor(.accentColor)
                            .font(.system(.title, weight: .regular))
                            .frame(width: 60, height: 50)
                            .clipped()
                        
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Attribute your success to the work you put into achieving those milestones.")
                                .font(.system(.footnote, weight: .semibold))
                            
                            Text("The most important step in using Milestones is to log your progress for each milestone. This allows you to reflect on the things you have done and the progress you made throughout the year.")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }
                        .fixedSize(horizontal: false, vertical: true)
                        
                        Spacer()
                    }
                    
                    HStack {
                        Image(systemName: "square.and.arrow.up")
                            .foregroundColor(.accentColor)
                            .font(.system(.title, weight: .regular))
                            .frame(width: 60, height: 50)
                            .clipped()
                        
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Share your work and achievements.")
                                .font(.system(.footnote, weight: .semibold))
                            
                            Text("The last step is to be proud of yourself for the milestones you finished. Some will be successful and some will fail. You will learn and grow from both. This makes it all the more important to share where you have put your effort in and what you took away from each of those experiences.")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }
                        .fixedSize(horizontal: false, vertical: true)
                        
                        Spacer()
                    }
                }
                .frame(maxWidth: 500)
                .padding(.bottom, 20)
            }
            
            Spacer()
            
            HStack {
                Spacer()
                Text("Explore application with example data (Recommended)")
                Spacer()
            }
            .foregroundColor(.white)
            .font(.system(.callout, weight: .semibold))
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color.accentColor)
            .mask { RoundedRectangle(cornerRadius: 13, style: .continuous) }
            .onTapGesture {
                addMilestones()
                dismiss()
            }
            
            Text("Skip")
                .foregroundColor(.accentColor)
                .font(.system(.subheadline, weight: .medium))
                .padding(.top, 8)
                .onTapGesture {
                    dismiss()
                }
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 20)
        .padding(.bottom, 20)
        .padding(.horizontal, 20)
    }
    
    func addMilestones() {
        let exampleMilestone1 = Milestone(
            title: "Participate in the Swift Student Challenge", milestoneDescription: "I want to create an app to participate in the Swift Student Challenge. The app should be called Milestones and help people deal with imposter syndrome and self-doubt by allowing them to track milestones they reach throughout the year.", startDate: date(year: 2023, month: 12, day: 27), endDate: date(year: 2024, month: 2, day: 25), creationDate: .now, status: .success, reward: "", nextStepsInCaseOfFailure: "")
        modelContext.insert(exampleMilestone1)
        
        let progressLog1ExampleMilestone1 = ProgressLog(progressDescription: "Started a new project in Swift Playgrounds for iPad", creationDate: date(year: 2023, month: 12, day: 27))
        modelContext.insert(progressLog1ExampleMilestone1)
        exampleMilestone1.progressLogs?.append(progressLog1ExampleMilestone1)
        
        let exampleMilestone2 = Milestone(
            title: "Develop an iOS app", milestoneDescription: "I want to develop an iOS application and submit it to the App Store. To do that I want to use the knowledge I accquired creating my Swift Student Challenge Submission.", startDate: date(year: 2024, month: 2, day: 25), endDate: date(year: 2024, month: 7, day: 31), creationDate: .now, status: .onTrack, reward: "As a reward, I am going to visit the Dolomites in August.", nextStepsInCaseOfFailure: "In case of failure the next step I want to take is to reflect on the things that did go wrong and then try again.")
        exampleMilestone2.category = .personal
        modelContext.insert(exampleMilestone2)
        
        let exampleMilestone3 = Milestone(
            title: "Intern at BMW", milestoneDescription: "I want to learn as much as possible from this oppertunity and give my best day in amd day out.", startDate: date(year: 2023, month: 10, day: 1), endDate: date(year: 2024, month: 3, day: 14), creationDate: .now, status: .onTrack, reward: "As a reward, I am going to buy a new MacBook Pro.", nextStepsInCaseOfFailure: "In case of failure the next step I want to take is to ask my collegues for feedback.")
        exampleMilestone3.category = .professional
        modelContext.insert(exampleMilestone3)
        
        let exampleMilestone4 = Milestone(
            title: "Train for 130km bike ride", milestoneDescription: "I want to regulary train for my longest bike ride yet.", startDate: date(year: 2024, month: 2, day: 18), endDate: date(year: 2024, month: 9, day: 6), creationDate: .now, status: .behindSchedule, reward: "Completing the bike ride is an reward itself.", nextStepsInCaseOfFailure: "In case of failure I dont want to give up and instead try again as soon as possible.")
        exampleMilestone4.category = .personal
        modelContext.insert(exampleMilestone4)
        
        let exampleMilestone5 = Milestone(
            title: "Prepare for university exams!", milestoneDescription: "I want to prepare for my upcoming computer science exams at university.", startDate: date(year: 2024, month: 3, day: 31), endDate: date(year: 2024, month: 7, day: 7), creationDate: .now, status: .onTrack, reward: "As I reward I will go hiking in the german alps.", nextStepsInCaseOfFailure: "In case of failure I need to get the information as to when I can take the exam next and I also need to sign up for the post exam-review to see what I did wrong.")
        exampleMilestone5.category = .academic
        modelContext.insert(exampleMilestone5)
    }
}

#Preview {
    OnboardingView()
}
