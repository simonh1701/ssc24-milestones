import SwiftUI

struct CalloutView: View {
    var headerText: String
    var markdownText: LocalizedStringKey
    var barColor: Color = .accentColor
    
    var body: some View {
        HStack {
            Rectangle()
                .foregroundStyle(barColor)
                .cornerRadius(.infinity)
                .frame(width: 5)
            
            VStack(alignment: .leading) {
                if !headerText.isEmpty {
                    Text(headerText)
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .padding(.bottom, 2)
                }
                
                Text(markdownText)
                    .font(.callout)
            }
            .padding(.horizontal, 5)
        }
    }
}

#Preview {
    CalloutView(
        headerText: "Header Text", 
        markdownText: "This is *markdown* Text", 
        barColor: .gray
    )
    .frame(width: 600, height: 100)
}
