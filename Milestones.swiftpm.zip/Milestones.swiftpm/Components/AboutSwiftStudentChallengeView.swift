import SwiftUI

struct AboutSwiftStudentChallengeView: View {
    @Environment(\.dismiss) var dismiss
    
    private var animatedSymbolCollection = AnimatedSymbolsCollection()
    @State private var animatonToogle = false
    
    let aboutSSCEasterEgg = AboutSSCEasterEgg()
    
    var body: some View {
        VStack {
            ZStack {
                ForEach(animatedSymbolCollection.animatedSymbols) { animatedSymbol in
                    Image(systemName: animatedSymbol.systemName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 20)
                        .offset(animatedSymbol.offset)
                        .rotationEffect(animatedSymbol.rotation)
                        .animation(.spring(response: 1, dampingFraction: 0.8), value: animatedSymbol.rotation)
                        .animation(.default, value: animatedSymbol.offset)
                        .animation(.default.delay(Double(animatedSymbolCollection.indexFor(animatedSymbol)) / 5), value: animatedSymbol.offset)
                        .foregroundStyle(.secondary)
                }
                
                Image(systemName: "swift")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 35, height: 35)
                    .padding()
                    .foregroundStyle(.white.shadow(.drop(radius: 10, x: 1, y: 1.5)))
                    .background {
                        Circle()
                            .shadow(color: .primary, radius: 80)
                            .foregroundStyle(Color.accentColor.gradient)
                            .scaleEffect(animatonToogle ? 1 : 0.9)
                            .onAppear {
                                withAnimation(.easeIn(duration: 2).repeatCount(5)) {
                                    animatonToogle = true
                                }
                            }
                    }
                    .popoverTip(aboutSSCEasterEgg)
            }
            .onTapGesture {
                aboutSSCEasterEgg.invalidate(reason: .actionPerformed)
                animatedSymbolCollection.randomizeOffsets()
            }
            
            Text("This is my Swift Student Challenge Submission.")
                .font(.title2)
                .fontWeight(.semibold)
                .hSpacing(.center)
                .padding(.top, 30)
                .padding(.bottom, 15)
            
            ScrollView(showsIndicators: false) {
                VStack {
                    Text("This app was created as a submission for the Apple Swift Student Challenge 2024.")
                        .hSpacing(.leading)
                    
                    Text("This app playground was created using a Mac mini and an iPad Pro. The playground is best viewed on the iPad.")
                        .foregroundStyle(.secondary)
                        .hSpacing(.leading)
                        .padding(.top, 10)
                    
                    SectionView(
                        systemName: "graduationcap.fill", 
                        heading: "About the creator", 
                        text: "Hey! 👋🏻 I am Simon Hohenwarter, a 22-year-old computer science student at Munich University of Applied Sciences. I am also an intern at BMW. I particularly enjoy designing and coding great user experiences. I started exploring app development with SwiftUI in the fall of last year and decided to participate in this year's Swift Student Challenge to test and improve my skills."
                    )
                    
                    RoundedRectangle(cornerRadius: .infinity)
                        .foregroundStyle(.separator)
                        .frame(width: .infinity, height: 1)
                        .padding(.vertical, 10)
                    
                    Text(
                        "I would like to take this opportunity to thank Apple and all of its employees for inspiring me to pursue a career as a software developer. The company and its products helped spark my passion for computer science. From my first iPod to my first iPhone and all the other products that followed, each showed me the incredible potential of technology and the impact it can have on the world. Although sometimes feeling like an imposter, I continue to explore and learn. Thank you for being a significant part of my journey and for motivating countless other students worldwide."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .hSpacing(.leading)
                    
                }
                .font(.footnote)
            }
        }
        .padding(.horizontal, 30)
        .padding(.bottom, 30)
        .frame(maxWidth: 900, alignment: .leading)
        .toolbar { 
            ToolbarItem(placement: .topBarTrailing) { 
                Circle()
                    .fill(Color(uiColor: .tertiarySystemFill))
                    .frame(width: 30, height: 30)
                    .overlay(
                        Image(systemName: "xmark")
                            .imageScale(.small)
                            .font(.callout.weight(.bold))
                            .foregroundColor(.secondary)
                    )
                    .padding(10)
                    .onTapGesture {
                        dismiss()
                    }
            }
        }
        .onAppear {
            Task { await AboutSSCEasterEgg.aboutSSCViewVisitedEvent.donate() }
        }
    }
}

struct SectionView: View {
    var systemName: String
    var heading: String
    var text: String
    
    var body: some View {
        VStack {
            HStack(spacing: 0) {
                Image(systemName: systemName)
                    .frame(width: 30)
                    .padding(.trailing, 8)
                
                Text(heading)
                    .font(.headline)
                    .fontWeight(.medium)
            }
            .padding(8)
            .foregroundStyle(Color.accentColor)
            .hSpacing(.leading)
            .background(Color.accentColor.opacity(0.15), in: .rect(cornerRadius: 10))
            .padding(.top, 20)
            .padding(.bottom, 10)
            
            Text(text)
                .hSpacing(.leading)
        }
    }
}

@Observable
class AnimatedSymbolsCollection {
    var animatedSymbols: [AnimatedSystemImage] = [
        AnimatedSystemImage("command"),
        AnimatedSystemImage("wrench.and.screwdriver"),
        AnimatedSystemImage("chevron.left.forwardslash.chevron.right"),
        AnimatedSystemImage("book"),
        AnimatedSystemImage("graduationcap"),
        AnimatedSystemImage("curlybraces"),
        AnimatedSystemImage("trophy"),
        AnimatedSystemImage("terminal"),
    ]
    
    func randomizeOffsets() {
        for index in animatedSymbols.indices {
            let randomWidth = CGFloat.random(in: 50...150)
            let negative = Bool.random()
            animatedSymbols[index].offset = CGSize(width: negative ? -randomWidth : randomWidth, height: CGFloat.random(in: -10...30))
            animatedSymbols[index].rotation = Angle(degrees: Double.random(in: -10...10))
        }
    }
    
    func indexFor(_ animatedSystemImage: AnimatedSystemImage) -> Int {
        if let index = animatedSymbols.firstIndex(where: { $0.id == animatedSystemImage.id }) {
            index
        } else {
            0
        }
    }
}

struct AnimatedSystemImage: Identifiable {
    var systemName: String
    
    var id = UUID()
    var offset: CGSize = .zero
    var rotation: Angle = .zero
    
    init(_ systemName: String) {
        self.systemName = systemName
    }
}

#Preview {
    NavigationStack {
        AboutSwiftStudentChallengeView()
    }
}
