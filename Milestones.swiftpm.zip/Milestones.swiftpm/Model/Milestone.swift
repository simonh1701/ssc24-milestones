import Foundation
import SwiftData
import SwiftUI
import Charts

@Model
class Milestone {
    var title: String
    var milestoneDescription: String
    
    var persistedStartDate: Date
    var persistedEndDate: Date
    
    @Transient
    var startDate: Date {
        get {
            return persistedStartDate
        }
        set(newStartDate) {
            if newStartDate <= endDate {
                persistedStartDate = newStartDate
            } else {
                print("Start date must be before or on end date. Setting to end date.")
                persistedStartDate = newStartDate
                persistedEndDate = newStartDate
            }
        }
    }
    
    @Transient
    var endDate: Date {
        get {
            return persistedEndDate
        }
        set(newEndDate) {
            if newEndDate >= startDate {
                persistedEndDate = newEndDate
            } else {
                print("End date must be after or on start date. Setting to start date.")
                persistedStartDate = newEndDate
                persistedEndDate = newEndDate
            }
        }
    }
    
    let creationDate: Date
    var category: Category?
    var status: Status
    var reward: String
    var nextStepsInCaseOfFailure: String
    
    @Transient
    var period: Period {
        return switch persistedEndDate {
        case let date where date < Date.now.addDays(-21):
                .past
        case let date where date <= Date.now.addDays(21):
                .current
        case let date where date <= Date.now.addDays(90):
                .nextNinetyDays
        case let date where date <= Date.now.endOfYear:
                .thisYear
        case let date where date < Date.now.endOfNextYear:
                .nextYear
        default: .future
        }
    }
    
    @Relationship(deleteRule: .cascade) var progressLogs: [ProgressLog]?
    
    init(title: String, milestoneDescription: String, startDate: Date, endDate: Date, creationDate: Date, category: Category? = nil, status: Status, reward: String, nextStepsInCaseOfFailure: String) {
        self.title = title
        self.milestoneDescription = milestoneDescription
        self.persistedStartDate = startDate
        self.persistedEndDate = endDate
        self.creationDate = creationDate
        self.category = category
        self.status = status
        self.reward = reward
        self.nextStepsInCaseOfFailure = nextStepsInCaseOfFailure
    }
    
    init() {
        self.title = ""
        self.milestoneDescription = ""
        self.persistedStartDate = .now.endOfMonth
        self.persistedEndDate = .now.endOfMonth.addDays(30)
        self.creationDate = .now
        self.category = nil
        self.status = .onTrack
        self.reward = ""
        self.nextStepsInCaseOfFailure = ""
    }
}

extension Milestone {
    enum Status: String, CaseIterable, Codable, Identifiable {
        case onTrack = "On Track"
        case behindSchedule = "Behind Schedule"
        case success = "Succeeded"
        case fail = "Failed"
        var id: String { self.rawValue }
        var name: String { self.rawValue }
        
        var description: LocalizedStringKey { 
            switch self {
            case .onTrack:
                "Great! You are on track with reaching this milestone."
            case .behindSchedule:
                "**Watch out!** You are behind your schedule to reach this milestone."
            case .fail:
                "Im sorry you missed this milestone. But thats okay... Look at the steps in case of failure."
            case .success:
                "Great job!"
            }    
        }
        
        var color: Color {
            switch self {
            case .onTrack:
                Color(0x009966)
            case .behindSchedule:
                Color(0xFD5D00)
            case .success:
                Color(0x00A0FD)
            case .fail:
                Color(0xB143AE)
            }
        }
        
        var systemImageName: String {
            switch self {
            case .onTrack:
                "calendar.badge.checkmark"
            case .behindSchedule:
                "exclamationmark.triangle.fill"
            case .fail:
                "xmark.circle.fill"
            case .success:
                "checkmark.seal.fill"
            }
        }
    }
}

extension Milestone {
    enum Category: String, CaseIterable, Codable, Identifiable, Plottable {
        case personal = "Personal"
        case academic = "Academic"
        case professional = "Professional"
        
        var id: String { self.rawValue }
        var name: String { self.rawValue }
        
        static func getCategory(from: String) -> Milestone.Category? {
            return switch from {
            case "personal": Milestone.Category.personal
            case "academic": Milestone.Category.academic
            case "professional": Milestone.Category.professional
            default: nil
            }
        }
    }
}


extension Array where Element == Milestone {
    func matchingItems(forPeriod period: Period) -> [Milestone] {
        return self.filter { $0.period == period }
    }
    
    func matchingItems(forCategory category: Milestone.Category?) -> [Milestone] {
        return self.filter { $0.category == category }
    }
    
    func matchingItems(forStatus status: Milestone.Status) -> [Milestone] {
        return self.filter { $0.status == status }
    }
}
