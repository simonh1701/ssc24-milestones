enum Period: String, CaseIterable, Identifiable {
    case current = "Current"
    case nextNinetyDays = "Next 90 Days"
    case thisYear = "This year"
    case nextYear = "Next Year"
    case future = "Distant Future"
    case past = "Past"
    
    var id: String { self.rawValue }
    var name: String { self.rawValue }
}
