import SwiftUI
import SwiftData

@Model
class ProgressLog {
    var progressDescription: String
    @Attribute(.externalStorage) var photos: [Data]
    let progressCreationDate: Date
    
    init(progressDescription: String, photos: [Data] = []) {
        self.progressDescription = progressDescription
        self.photos = photos
        self.progressCreationDate = .now
    }
    
    init(progressDescription: String, creationDate: Date, photos: [Data] = []) {
        self.progressDescription = progressDescription
        self.photos = photos
        self.progressCreationDate = creationDate
    }
    
    var milestone: Milestone?
}
