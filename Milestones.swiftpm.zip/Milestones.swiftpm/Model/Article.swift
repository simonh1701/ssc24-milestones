import SwiftUI

struct Article: Identifiable, View {
    var id: String
    var title: String
    var description: String
    var systemImage: String
    var backgroundColor: Color
    
    @State private var selectedTypeIndex = 0
    
    var typeTexts = [
        "The Perfectionist. This type of imposter syndrome involves believing that, unless you were absolutely perfect, you could have done better. You feel like an imposter because your perfectionistic traits make you believe that you're not as good as others might think you are.",
        "The Expert. The expert feels like an imposter because they don't know everything there is to know about a particular subject or topic, or they haven't mastered every step in a process. Because there is more for them to learn, they don't feel as if they've reached the rank of 'expert.''",
        "The Natural Genius. In this imposter syndrome type, you may feel like a fraud simply because you don't believe that you are naturally intelligent or competent. If you don't get something right the first time around or it takes you longer to master a skill, you feel like an imposter.",
        "The Soloist. It's also possible to feel like an imposter if you had to ask for help to reach a certain level or status. Since you couldn't get there on your own, you question your competence or abilities.",
        "The Superperson. This type of imposter syndrome involves believing that you must be the hardest worker or reach the highest levels of achievement possible and, if you don't, you are a fraud."
    ]
    
    var body: some View {
        if id == "article-1" {
            VStack(alignment: .leading) {
                Text("This is a shortened version of the article")
                    .font(.caption)
                    .padding(.top, 10)
                
                Link("Imposter Syndrome: Why You May Feel Like a Fraud by Arlin Cuncic, MA", destination: URL(string: "https://www.verywellmind.com/imposter-syndrome-and-social-anxiety-disorder-4156469")!)
                    .font(.caption)
                    .lineLimit(1)
                    .hSpacing(.leading)
                
                VStack(alignment: .leading) {
                    Text("What is imposter syndrome?").font(.title).fontWeight(.bold).padding(.bottom)
                    Text("Imposter syndrome is the psychological experience of feeling like a fake or a phony despite any genuine success that you have achieved. It can show up in the context of work, relationships, friendships, or just overall. It's a very common and frustrating phenomenon because it holds us back from the self-confidence we've earned and deserve to feel.")
                    CalloutView(headerText: "", markdownText: "**You might have imposter syndrome if you find yourself consistently experiencing self-doubt, even in areas where you typically excel. Imposter syndrome may feel like nervousness, accompanied by the belief you'll be 'found out' and it may also manifest as negative self-talk. Symptoms of anxiety and depression often accompany imposter syndrome.**", barColor: .accentColor)
                    
                    Text("How Do I Know If I Have Imposter Syndrome?").font(.title).fontWeight(.bold).padding(.vertical)
                    Text("""
Imposter syndrome can affect anyone—no matter their social status, work background, skill level, or degree of expertise.

While impostor syndrome is not a recognized mental health disorder in the Diagnostic and Statistical Manual of Mental Disorders (DSM-5-TR), it is fairly common. It is estimated that 70% of people will experience at least one episode of this phenomenon at some point in their lives.

If you wonder whether you might have imposter syndrome, ask yourself the following questions:
""")
                    Text("""
- Do you agonize over even the smallest mistakes or flaws in your work?
- Do you attribute your success to luck or outside factors?
- Are you sensitive to even constructive criticism?
- Do you feel like you will inevitably be found out as a phony?
- Do you downplay your own expertise, even in areas where you are genuinely more skilled than others?
""")
                    .font(.system(size: 14))
                    .padding(.top, 10)
                    
                    Text("What Does Imposter Syndrome Feel Like?").font(.title).fontWeight(.bold).padding(.vertical)
                    Text("Some common characteristics of imposter syndrome include:")
                    Text("""
- An inability to realistically assess your competence and skills
- Attributing your success to external factors
- Berating your performance
- Fear that you won't live up to expectations
- Overachieving 
- Sabotaging your own success
- Self-doubt
- Setting very challenging goals and feeling disappointed when you fall short
""")
                    .font(.system(size: 14))
                    .padding(.top, 10)
                    
                    Text("The Five Types of Imposter Syndrome").font(.title).fontWeight(.bold).padding(.vertical)
                    
                    VStack {
                        Picker("The Five Types of Imposter Syndrome", selection: $selectedTypeIndex) {
                            Text("The Perfectionist").tag(0)
                            Text("The Expert").tag(1)
                            Text("The Natrual Genius").tag(2)
                            Text("The Soloist").tag(3)
                            Text("The Superperson").tag(4)
                        }
                        .pickerStyle(.segmented)
                        
                        Text(typeTexts[selectedTypeIndex])
                            .hSpacing(.leading)
                    }
                    .padding(.bottom, 10)
                    
                    Text("Coping With Imposter Syndrome").font(.title).fontWeight(.bold).padding(.vertical)
                    Text("To get past impostor syndrome, it helps to start asking yourself some hard questions. Here are a few to consider:")
                    Text("""
- What core beliefs do I hold about myself?
- Do I believe I am worthy of love as I am?
- Must I be perfect for others to approve of me?
""")
                    .font(.system(size: 14))
                    .padding(.vertical, 10)
                    
                    Text("To move past these feelings, you need to become comfortable confronting some of the deeply ingrained beliefs you hold about yourself. This exercise can be hard because you might not even realize that you hold them, but here are some techniques you can use:")
                    Text("""
- **Share your feelings.** Talk to other people about how you are feeling. Irrational beliefs tend to fester when they are hidden and not talked about.

- **Focus on others.** While this might feel counterintuitive, try to help others in the same situation as you. If you see someone who seems awkward or alone, ask them a question to bring them into the group. As you practice your skills, you will build confidence in your own abilities.

- **Assess your abilities.** If you have long-held beliefs about your incompetence in social and performance situations, make a realistic assessment of your abilities. Write down your accomplishments and what you are good at, then compare these with your self-assessment.

- **Take baby steps.** Don't focus on doing things perfectly, but rather, do things reasonably well and reward yourself for taking action. For example, in a group conversation, offer an opinion or share a story about yourself.

- **Question your thoughts.** As you start to assess your abilities and take baby steps, question whether your thoughts are rational. Does it make sense to believe that you are a fraud given everything that you know?

- **Stop comparing.** Every time you compare yourself to others in a social situation, you will find some fault with yourself that fuels the feeling of not being good enough or not belonging. Instead, during conversations, focus on listening to what the other person is saying. Be genuinely interested in learning more.

- **Use social media moderately.** We know that the overuse of social media may be related to feelings of inferiority. If you try to portray an image on social media that doesn't match who you really are or that is impossible to achieve, it will only make your feelings of being a fraud worse.

- **Stop fighting your feelings.** Don't fight the feelings of not belonging. Instead, try to lean into them and accept them. It's only when you acknowledge these feelings that you can start to unravel the core beliefs that are holding you back.

- **Refuse to let it hold you back.** No matter how much you feel like you are a fraud or that you don't belong, don't let that stop you from pursuing your goals. Keep going and refuse to be stopped.
""")
                    .font(.system(size: 14))
                    .padding(.top, 10)
                }
                .hSpacing(.leading)
                .padding(.vertical, 10)
            }
            .font(.system(size: 18))
        } else {
            VStack(alignment: .leading) {
                Text(dummyText)
                    .multilineTextAlignment(.leading)
                    .lineSpacing(10)
                    .padding(.bottom,20)
            }
        }
    }
}

extension Article {
    var image: Image {
        Image("article/\(id)", label: Text(title))
            .renderingMode(.original)
    }
}

extension Article {
    static let article1 = Article(id: "article-1", title: "All you need to know about imposter syndrome.", description: "Find out what it is and what types there are.", systemImage: "heart.text.square", backgroundColor: .accentColor)
}

extension Article {
    static let all: [Article] = [
        .article1,
    ]
    
    init?(for id: Article.ID) {
        guard let result = Article.all.first(where: { $0.id == id }) else {
            return nil
        }
        self = result
    }
}

var dummyText = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like)."
