import Foundation
import SwiftData

@MainActor
struct Previewer {
    let container: ModelContainer
    let category: Milestone.Category
    let milestone: Milestone
    let progressLog: ProgressLog
    
    init() throws {
        let config = ModelConfiguration(isStoredInMemoryOnly: true)
        container = try ModelContainer(for: Milestone.self, configurations: config)
        
        category = Milestone.Category.personal
        
        milestone = Milestone(
            title: "Preview Milestone", 
            milestoneDescription: "This is the description for the preview milestone", 
            startDate: .now.endOfMonth,
            endDate: .now.endOfYear,
            creationDate: .now, 
            category: Optional(category), 
            status: .onTrack,
            reward: "", 
            nextStepsInCaseOfFailure: ""
        )
        
        container.mainContext.insert(milestone)
        
        progressLog = ProgressLog(progressDescription: "Progress Log 1")
        container.mainContext.insert(progressLog)
        milestone.progressLogs?.append(progressLog)
        
        let milestone2 = Milestone(
            title: "Preview Milestone", 
            milestoneDescription: "This is the description for the preview milestone", 
            startDate: .now.endOfMonth,
            endDate: .now.endOfYear,
            creationDate: .now, 
            category: Optional(category), 
            status: .onTrack,
            reward: "", 
            nextStepsInCaseOfFailure: ""
        )
        
        container.mainContext.insert(milestone2)
        
        let milestone3 = Milestone(
            title: "Preview Milestone", 
            milestoneDescription: "This is the description for the preview milestone", 
            startDate: .now.endOfMonth,
            endDate: .now.endOfYear,
            creationDate: .now, 
            category: Optional(category), 
            status: .onTrack,
            reward: "", 
            nextStepsInCaseOfFailure: ""
        )
        
        container.mainContext.insert(milestone3)
    }
}
