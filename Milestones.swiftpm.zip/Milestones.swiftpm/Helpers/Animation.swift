import SwiftUI

extension Animation {
    static let openArticle = Animation.easeIn(duration: 0.3)
    static let closeArticle = Animation.easeOut(duration: 0.3)
}
