import SwiftUI

struct MilestoneCardNavLinkView: View {
    @Environment(\.modelContext) var modelContext
    
    var milestone: Milestone
    
    var body: some View {
        NavigationLink(value: milestone) {
            MilestoneCardView(milestone: milestone)
                .contextMenu(ContextMenu {
                    Button(role: .destructive) {
                        deleteMilestone(milestone)
                    } label: {
                        Label("Delete", systemImage: "trash")
                    }
                })
        }
    }
    
    func deleteMilestone(_ milestone: Milestone) {
        modelContext.delete(milestone)
    }
}
