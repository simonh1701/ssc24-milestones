import SwiftUI
import SwiftData

struct MilestoneNavigationStack: View {
    @Environment(\.modelContext) var modelContext
    @State private var path = [Milestone]()
    @State private var searchString: String = ""
    @AppStorage("selectedGroupByAttribute") private var selectedGroupByAttribute: GroupByAttributes = .endDate
    
    var body: some View {
        NavigationStack(path: $path) { 
            MilestonesOverviewView(groupBy: selectedGroupByAttribute, searchString: searchString)
                .navigationTitle("Overview")
                .toolbar {
                    ToolbarItem(placement: .primaryAction) { 
                        Button("Add Milestone", systemImage: "plus", action: addMilestone)
                    }
                    
                    ToolbarItemGroup(placement: .secondaryAction) {
                        Picker("Group By", systemImage: "square.grid.3x1.below.line.grid.1x2", selection: $selectedGroupByAttribute) {
                            ForEach(GroupByAttributes.allCases) { groupByAttribute in
                                Text(groupByAttribute.rawValue).tag(groupByAttribute)
                            }
                        }
                    }
                }
                .searchable(text: $searchString, placement: .toolbar, prompt: "Search milestones")
                .navigationDestination(for: Milestone.self) { milestone in
                    EditMilestoneView(milestone: milestone, navigationPath: $path)
                }
        }
    }
    
    func addMilestone() {
        let newMilestone = Milestone()
        modelContext.insert(newMilestone)
        path.append(newMilestone)
    }
    
    func deleteAllMilestones() {
        do {
            try modelContext.delete(model: Milestone.self)
        } catch {
            print("Failed to delete Milestone data")
        }
    }
}

enum GroupByAttributes: String, CaseIterable, Identifiable {
    case endDate = "End Date"
    case category = "Category"
    case status = "Status"
    
    var id: String { self.rawValue }
}
