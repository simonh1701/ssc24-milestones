import SwiftUI
import SwiftData

struct MilestoneCardView: View {
    @Environment(\.colorScheme) var colorScheme
    
    var milestone: Milestone
    var color: Color = .primary
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 13, style: .continuous)
                .fill(milestone.status.color.gradient)
            
            VStack(alignment: .leading) {
                VStack {
                    VStack {
                        Text(milestone.title.isEmpty ? "New milestone" : milestone.title)
                            .fontWeight(.bold)
                            .fontWidth(.condensed)
                            .lineLimit(1)
                            .hSpacing(.leading)
                        
                        Text(milestone.category?.name ?? "No Category")
                            .font(.system(size: 10))
                            .fontWeight(.semibold)
                            .padding(.vertical, 4)
                            .padding(.horizontal, 6)
                            .lineLimit(1)
                            .background {
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(lineWidth: 1)
                            }
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                            .padding(.top, 2)
                            .opacity(milestone.category == nil ? 0 : 1)
                    }
                    
                    Spacer(minLength: 30)
                    
                    HStack {
                        VStack(alignment: .leading, spacing: 0) {
                            Image(systemName: milestone.status.systemImageName)
                                .font(.system(size: 18))
                                .help(milestone.status.name)
                            
                            Spacer(minLength: 0)
                            
                            Text("Status".uppercased())
                                .font(.system(size: 10, weight: .regular, design: .rounded))
                                .padding(.top, 5)
                        }
                        
                        Spacer()
                        
                        VStack(alignment: .trailing, spacing: 0) {
                            Text(milestone.endDate.formatted(date: .numeric, time: .omitted))
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                            
                            Spacer(minLength: 0)
                            
                            Text("End Date".uppercased())
                                .font(.system(size: 10, weight: .regular, design: .rounded))
                        }
                    }
                }
                .padding(13)
                .foregroundStyle(milestone.status.color)
                .background(.thickMaterial, in: .rect(cornerRadius: 8, style: .continuous))
                .padding(5)
                .contentShape(.rect(cornerRadius: 13))
                .clipShape(.rect(cornerRadius: 13))
            }
        }
    }
}

#Preview {
    let columns = [
        GridItem(.adaptive(minimum: 250), spacing: 15),
    ]
    
    do {
        let previewer = try Previewer()
        previewer.milestone.status = .fail
        
        return LazyVGrid(columns: columns, spacing: 15) {
            ForEach(0..<4) { index in 
                MilestoneCardView(milestone: previewer.milestone)
            }
        }
        .padding()
        .modelContainer(previewer.container)
    } catch {
        return Text("Failed to create preview: \(error.localizedDescription)")
    }
}
