import SwiftUI
import SwiftData
import CoreML

struct EditMilestoneView: View {
    @Environment(\.modelContext) var modelContext
    
    @Bindable var milestone: Milestone
    @Binding var navigationPath: [Milestone]
    
    @State private var showingDeleteConfirmation = false
    @State private var showingManageCategoriesView = false
    
    var categories: [Milestone.Category] = Milestone.Category.allCases
    
    var body: some View {
        Group {
            Form {
                Section {
                    TextField("Title", text: $milestone.title)
                        .font(.title2)
                    
                    TextField("Description", text:$milestone.milestoneDescription, axis: .vertical)
                        .lineLimit(3...8)
                }
                
                Section {
                    DatePicker("Start Date", selection: $milestone.startDate, displayedComponents: [.date])
                    DatePicker("End Date", selection: $milestone.endDate, displayedComponents: [.date])
                    
                    Picker("Category", selection: $milestone.category) {
                        Text("No category")
                            .tag(Optional<Milestone.Category>.none)
                        
                        if categories.isEmpty == false {
                            Divider()
                            
                            ForEach(categories) { category in
                                Text(category.name)
                                    .tag(Optional(category))
                            }
                        }
                    }
                    
                    Button(action: { 
                        guard !milestone.title.isEmpty else { 
                            milestone.category = nil 
                            return
                        }
                        let mlCategory = categorizeMilestone(text: milestone.title)
                        
                        milestone.category = mlCategory
                    }, label: {
                        Label("Categorize with Machine Learning based on title", systemImage: "rectangle.and.text.magnifyingglass")
                    })
                }
                
                Section {
                    Picker(selection: $milestone.status) {
                        ForEach(Milestone.Status.allCases) { status in
                            Label(status.name, systemImage: status.systemImageName)
                                .foregroundStyle(status.color)
                                .tag(status)
                        } 
                    } label: {
                        MilestoneStatusBannerView(status: milestone.status)
                            .padding(.vertical, 10)
                    }
                    .pickerStyle(.navigationLink)
                } header: {
                    Text("Status")
                } footer: {
                    Text("The status can indicate how well the milestone is progressing or how it was finished.")
                }
                
                Section {
                    TextField("How are you planning to reward yourself for reaching this milestone?", text: $milestone.reward, axis: .vertical)
                } header: {
                    Text("Reward")
                } footer: {
                    Text("It is important to reward yourself after completing a milestone. This can help to keep motivation and excitement high. Remember: This should not be for succeeding, but rather for giving it your best effort.")
                }
                
                Section {
                    TextField("What are your next steps going to be if you fail to reach this milestone?", text:$milestone.nextStepsInCaseOfFailure, axis: .vertical)
                } header: {
                    Text("Next steps in case of failure")
                } footer: {
                    Text("Here you can enter a backup plan for when things go not as expected. This helps to plan for the worst outcomes. It brings ease of mind to already know what to do if such a case should occur.")
                }
                
                Section {
                    let sortedProgressLogs = milestone.progressLogs?.sorted(using: KeyPathComparator(\ProgressLog.progressCreationDate)) ?? []
                    List {
                        ForEach(0..<sortedProgressLogs.count, id: \.self) { i in
                            EditProgressLogView(progressLog: sortedProgressLogs[i], index: i) 
                                .padding(.vertical, 10)
                        }
                        .onDelete { indexSet in 
                            indexSet.forEach { index in 
                                if let progressLog = milestone.progressLogs?[index] {
                                    modelContext.delete(progressLog)
                                }    
                            }
                        }
                    }
                    
                    Button(action: addNewProgressLog) {
                        HStack(spacing: 15) {
                            Image(systemName: "plus.app")
                                .frame(width: 30, height: 30)
                            
                            Text("Log new progress")
                        }
                    }
                } header: {
                    Text("Progress")
                } footer: {
                    Text("Log your latest progress, no matter how small it may be. Remember: The only thing that counts is moving forwards.")
                }
            }
        }
        .navigationTitle("Edit Milestone")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    func deleteMilestone() {
        print("Deleting milestone...")
        navigationPath.removeLast()
        modelContext.delete(milestone)
    }
    
    func addNewProgressLog() {
        print("Adding new progress log...")
        let newProgressLog = ProgressLog(progressDescription: "")
        modelContext.insert(newProgressLog)
        milestone.progressLogs?.append(newProgressLog)
    }
    
    func categorizeMilestone(text: String) -> Milestone.Category? {
        do {
            let config = MLModelConfiguration()
            let model = try MyMilestoneClassifier(configuration: config)
            
            let prediction = try model.prediction(text: text)
            
            return Milestone.Category.getCategory(from: prediction.label)
        } catch {
            print(error)
            print("Error occured!")
            return nil
        }
    }
}

#Preview {
    do {
        let previewer = try Previewer()
        
        return NavigationStack {
            EditMilestoneView(
                milestone: previewer.milestone, 
                navigationPath: .constant([Milestone]())
            )
        }
        .modelContainer(previewer.container)
    } catch {
        return Text("Failed to create preview: \(error.localizedDescription)")
    }
}
