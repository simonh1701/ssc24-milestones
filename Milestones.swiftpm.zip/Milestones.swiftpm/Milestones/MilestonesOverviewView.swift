import SwiftUI
import SwiftData

struct MilestonesOverviewView: View {
    @Environment(\.modelContext) var modelContext
    @Environment(\.isSearching) private var isSearching
    
    var groupBy: GroupByAttributes
    
    @Query private var milestones: [Milestone]
    
    init(groupBy: GroupByAttributes, searchString: String = "") {
        self.groupBy = groupBy
        
        _milestones = Query(filter: #Predicate<Milestone> { milestone in 
            if searchString.isEmpty {
                true
            } else {
                milestone.title.localizedStandardContains(searchString)
                || milestone.milestoneDescription.localizedStandardContains(searchString)
            }
        }, sort: [
            SortDescriptor(\Milestone.persistedEndDate, order: .reverse),
            SortDescriptor(\Milestone.creationDate, order: .reverse)
        ])
    }
    
    let columns = [
        GridItem(.adaptive(minimum: 230)),
    ]
    
    var body: some View {
        Group {
            if milestones.isEmpty && isSearching {
                ContentUnavailableView.search
            } else if milestones.isEmpty {
                ContentUnavailableView("No milestones", systemImage: "", description: Text("Tap on the plus icon to add an milestone.")) 
            } else {
                ScrollView(.vertical) {
                    LazyVGrid(columns: columns, pinnedViews: [.sectionHeaders]) {
                        switch(groupBy) {
                        case .endDate:
                            GroupByEndDateView(milestones: milestones)
                        case .category:
                            GroupByCategoryView(milestones: milestones)
                        case .status: 
                            GroupByStatusView(milestones: milestones)
                        }
                    }
                    .padding(.horizontal, 20)
                }
            }
        }
    }
}

struct GroupByEndDateView: View {
    var milestones: [Milestone]
    
    var body: some View {
        ForEach(Period.allCases) { period in
            Group {
                let filteredMilestones = milestones.matchingItems(forPeriod: period)
                
                if filteredMilestones.count > 0 {
                    MilestoneSectionView(milestonesInThisSection: filteredMilestones, sectionHeader: period.name)
                }
            }
        }
    }
}

struct GroupByCategoryView: View {
    var milestones: [Milestone]
    
    var categories: [Milestone.Category] = Milestone.Category.allCases
    
    var body: some View {
        Group {
            let filteredMilestonesNoCategory = milestones.matchingItems(forCategory: nil)
            
            if filteredMilestonesNoCategory.count > 0 {
                MilestoneSectionView(milestonesInThisSection: filteredMilestonesNoCategory, sectionHeader: "No category")
            }
            
            if categories.isEmpty == false {
                ForEach(categories) { category in
                    Group {
                        let filteredMilestones = milestones.matchingItems(forCategory: category)
                        
                        if filteredMilestones.count > 0 {
                            MilestoneSectionView(milestonesInThisSection: filteredMilestones, sectionHeader: category.name)
                        }
                    }
                }
            }
        }
    }
}

struct GroupByStatusView: View {
    var milestones: [Milestone]
    
    var body: some View {
        Group {
            ForEach(Milestone.Status.allCases) { status in
                Group {
                    let filteredMilestones = milestones.matchingItems(forStatus: status)
                    
                    if filteredMilestones.count > 0 {
                        MilestoneSectionView(milestonesInThisSection: filteredMilestones, sectionHeader: status.name)
                    }
                }
            }
        }
    }
}
