import SwiftUI
import SwiftData
import PhotosUI

struct EditProgressLogView: View {
    @Environment(\.modelContext) var modelContext
    
    @Bindable var progressLog: ProgressLog
    var index: Int
    
    @State private var showingPhotosPicker = false
    @State private var selectedItems: [PhotosPickerItem] = []
    @State private var images: [UIImage] = []
    @State private var showingDeleteConfirmation = false
    
    var body: some View {
        VStack(spacing: 10) {
            HStack(alignment: .top, spacing: 15) {
                Image(systemName: "arrow.up.forward.app.fill")
                    .font(.largeTitle)
                    .foregroundStyle(.primary)
                    .frame(width: 30, height: 30)
                    .background { 
                        Circle().fill(.ultraThickMaterial)
                    }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Progress Log #\(index + 1)")
                        .fontWeight(.semibold)
                        .textScale(.secondary)
                        .padding(.bottom, 10)
                    
                    TextEditor(text: $progressLog.progressDescription)
                        .padding(.horizontal, 3)
                        .frame(minHeight: 50)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.secondary.opacity(0.2), lineWidth: 1)
                        )
                }
            }
            
            VStack(alignment: .leading, spacing: 10) {
                if (progressLog.photos.count > 0) {
                    GeometryReader {
                        let size = $0.size
                        
                        ScrollView(.horizontal) {
                            HStack(spacing: 10) {
                                ForEach(progressLog.photos, id: \.self) { imageData in
                                    LazyHStack {
                                        if let uiImage = UIImage(data: imageData) {
                                            Image(uiImage: uiImage)
                                                .resizable()
                                                .aspectRatio(contentMode: .fill)
                                                .frame(maxWidth: size.width)
                                                .clipShape(.rect(cornerRadius: 10))
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 10)
                                                        .stroke(Color.secondary.opacity(0.2), lineWidth: 1)
                                                )
                                        }
                                    }
                                    .frame(maxWidth: size.width)
                                    .frame(height: size.height)
                                    .contentShape(.rect)
                                }
                            }
                            .scrollTargetLayout()
                        }
                        .scrollIndicators(.hidden)
                        .scrollTargetBehavior(.viewAligned)
                    }
                    .frame(height: 200)
                }
                
                HStack(spacing: 10) {
                    Image(systemName: "photo.on.rectangle.angled")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 30, height: 30)
                        .foregroundStyle(Color.accentColor)
                        .onTapGesture {
                            showingPhotosPicker = true
                        }
                        .photosPicker(isPresented: $showingPhotosPicker, selection: $selectedItems, maxSelectionCount: 4, selectionBehavior: .ordered, matching: .images)
                    
                    Spacer()
                }
            }
            .safeAreaPadding(.leading, 45)
            
            HStack(spacing: 15) {
                Image(systemName: "calendar")
                    .frame(width: 30, height: 30)
                    .background { 
                        Circle().fill(.ultraThickMaterial)
                    }
                
                Text(progressLog.progressCreationDate.formatted(date: .complete, time: .omitted))
                
                Spacer()
            }
            .textScale(.secondary)
            .foregroundStyle(.secondary)
        }
        .background(alignment: .leading) {
            Rectangle()
                .fill(.secondary.opacity(0.2))
                .frame(width: 1)
                .padding(.bottom, 30)
                .offset(x: 15, y: 10)
        }
        .onChange(of: selectedItems, loadPhotos)
    }
    
    func loadPhotos() {
        Task { @MainActor in
            var imagesData: [Data] = []
            
            for selectedItem in selectedItems {
                if let imageData = try await selectedItem.loadTransferable(type: Data.self) {
                    imagesData.append(imageData)
                }
            }
            
            progressLog.photos = imagesData
        }
    }
    
    func deleteProgressLog() {
        modelContext.delete(progressLog)
    }
}

#Preview {
    do {
        let previewer = try Previewer()
        
        return Group {
            EditProgressLogView(progressLog: previewer.progressLog, index: 0)
                .modelContainer(previewer.container)
        }
    } catch {
        return Text("Failed to create preview: \(error.localizedDescription)")
    }
}
