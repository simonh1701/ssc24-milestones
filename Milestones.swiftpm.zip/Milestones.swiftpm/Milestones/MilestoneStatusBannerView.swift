import SwiftUI
import SwiftData

struct MilestoneStatusBannerView: View {
    var status: Milestone.Status
    
    var body: some View {
        HStack {
            Rectangle()
                .foregroundStyle(status.color)
                .cornerRadius(.infinity)
                .frame(width: 5)
            
            VStack(alignment: .leading, spacing: 10) {
                Text(status.description)
                    .hSpacing(.leading)
            }
            .padding(.horizontal, 5)
        }
        .foregroundStyle(status.color)
    }
}

#Preview {
    ForEach(0..<4) { index in 
        MilestoneStatusBannerView(status: .success)
    }
    .padding()
}
