import SwiftUI

struct MilestoneSectionView: View {
    var milestonesInThisSection: [Milestone]
    var sectionHeader: String
    
    var body: some View {
        Section(content: {
            ForEach(milestonesInThisSection) { milestone in 
                MilestoneCardNavLinkView(milestone: milestone)
            }
        }, header: {
            Text(sectionHeader.uppercased())
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .fontWeight(.bold)
                .padding(5)
                .background()
                .backgroundStyle(.thickMaterial)
                .clipShape(.rect(cornerRadius: 4, style: .continuous))
                .shadow(radius: 40)
                .padding(.top, 10)
                .padding(.bottom, 5)
                .hSpacing(.leading)
        })
    }
}
