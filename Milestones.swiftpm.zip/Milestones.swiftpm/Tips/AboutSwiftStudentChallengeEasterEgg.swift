import SwiftUI
import TipKit

struct AboutSSCEasterEgg: Tip {
    static let aboutSSCViewVisitedEvent = Event(id: "aboutSSCViewVisited")
    
    var title: Text {
        Text("Discover a easter egg!")
    }
    
    var message: Text? {
        Text("Tap the circle a few times for a little suprise!")
    }
    
    var rules: [Rule] {
        #Rule(Self.aboutSSCViewVisitedEvent) { event in
            event.donations.count > 1
        }
    }
}
