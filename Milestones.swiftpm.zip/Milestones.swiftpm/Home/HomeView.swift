import SwiftUI
import SwiftData

struct HomeView: View {
    @Query(sort: \Milestone.persistedEndDate) private var milestones: [Milestone]
    @State var currentIndex : Int = 0
    
    var articleItems: [Article] = Article.all
    
    @Environment(\.colorScheme) private var colorScheme
    
    @State private var selectedArticleID: Article.ID?
    @State private var topmostArticleID: Article.ID?
    @Namespace private var namespace
    
    var body: some View {
        container
            .safeAreaPadding(.horizontal, 20)
    }
    
    var container: some View {
        ZStack {
            
            ScrollView() {
                SlidingCardStackView(index : $currentIndex, cards: milestones.filter({ milestone in milestone.startDate <= Date.now.endOfDay && milestone.endDate >= Date.now.startOfDay })) { index, item in
                    Group {
                        if currentIndex == index {
                            NavigationLink(value: item) {
                                MilestoneCardView(milestone: item)
                            }
                        } else {
                            MilestoneCardView(milestone: item)
                        }
                    }.frame(width: 275, height: 155)
                }
                .frame(height: 155)
                .padding(.top)
                
                MilestoneTimelineView()
                    .padding(.top)
                
                Text("Learn about imposter syndrome!")
                    .font(.title)
                    .hSpacing(.leading)
                    .padding(.top)
                
                content
            }
            .scrollIndicators(.never)
            .scrollClipDisabled()
            
            Rectangle().fill(.background).ignoresSafeArea()
                .opacity(selectedArticleID == nil ? 0 : 1)
            
            ForEach(articleItems) { article in
                let presenting = selectedArticleID == article.id
                if presenting {
                    ArticleGraphic(
                        article: article, 
                        style: .detail, 
                        closeAction: deselectArticle
                    )
                    .matchedGeometryEffect(
                        id: article.id, 
                        in: namespace, 
                        isSource: presenting
                    )
                    .zIndex(topmostArticleID == article.id ? 1 : 0)
                }
            }
            .padding(.top)
        }
    }
    
    var content: some View {
        ForEach(articleItems) { article in
            let presenting = selectedArticleID == article.id
            
            ArticleGraphic(article: article, style: .thumbnail)
                .matchedGeometryEffect(
                    id: article.id,
                    in: namespace,
                    isSource: !presenting
                )
                .onTapGesture(perform: {
                    select(article: article) 
                })
                .animation(.easeInOut(duration: 0.3), value: presenting)
                .zIndex(topmostArticleID == article.id ? 1 : 0)
        }
    }
    
    func select(article: Article) {
        topmostArticleID = article.id
        withAnimation(.openArticle) {
            selectedArticleID = article.id
        }
    }
    
    func deselectArticle() {
        withAnimation(.closeArticle) {
            selectedArticleID = nil
        }
        topmostArticleID = nil
    }
}
