import Charts
import SwiftUI
import SwiftData

struct MilestoneTimelineView: View {
    @Query private var milestones: [Milestone]
    
    private let rangeStart: Date = .now.addDays(-90)
    private let rangeEnd: Date = .now.addDays(365)
    
    var body: some View {
        TimelineChart(
            headerTitle: "Timeline",
            milestones: milestones,
            chartXScaleRangeStart: rangeStart,
            chartXScaleRangeEnd: rangeEnd
        )
    }
}

#Preview {
    do {
        let previewer = try Previewer()
        
        return MilestoneTimelineView()
            .safeAreaPadding(.horizontal, 20)
            .modelContainer(previewer.container)
    } catch {
        return Text("Failed to create preview: \(error.localizedDescription)")
    }
}
