import SwiftUI

struct ArticleCard: View {
    var article: Article
    var presenting: Bool
    var closeAction: () -> Void = {}
    
    var body: some View {
        ArticleGraphic(article: article, style: presenting ? .detail : .thumbnail, closeAction: closeAction)
            .contentShape(Rectangle())
    }
}

struct ArticleGraphic: View {
    var article: Article
    var style: Style
    var closeAction: () -> Void = {}
    
    enum Style {
        case detail
        case thumbnail
    }
    
    var shape = RoundedRectangle(cornerRadius: 15, style: .continuous)
    
    var body: some View {
        ScrollView { 
            CardView()
            
            if style == .detail {
                article
                    .padding(.top)
            }
            
            Spacer()
        }
        .scrollDisabled(style == .thumbnail)
        .scrollIndicators(.never)
        .vSpacing(.leading)
        .clipShape(shape)
        .contentShape(shape)
    }
    
    func cardControls() -> some View {
        VStack {
            ActionButton(label: "Close", systemImage: "xmark.circle.fill", action: closeAction)
                .foregroundStyle(.white)
                .scaleEffect(style == .detail ? 1 : 0.5)
                .opacity(style == .detail ? 1 : 0)
            
            Spacer()
        }
        .frame(maxWidth: .infinity, alignment: .trailing)
    }
    
    @ViewBuilder
    func CardView() -> some View{
        VStack(alignment: .leading, spacing: 15) {
            ZStack(alignment: .topLeading) {
                GeometryReader { proxy in
                    let size = proxy.size
                    
                    Rectangle()
                        .fill(article.backgroundColor.gradient)
                        .aspectRatio(contentMode: .fill)
                        .frame(width: size.width, height: size.height)
                        .overlay { 
                            Image(systemName: article.systemImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
                                .padding(.top, 40)
                                .offset(x: 30, y: 40)
                                .blendMode(.overlay)
                        }
                        .clipShape(.rect(cornerRadius: 15))
                    
                    LinearGradient(colors: [
                        .black.opacity(0.5),
                        .black.opacity(0.2),
                        .clear
                    ], startPoint: .top, endPoint: .bottom)
                    .frame(width: size.width, height: size.height)
                    .clipShape(.rect(cornerRadius: 15))
                }
                .frame(height: 250)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text(article.description.uppercased())
                        .font(.callout)
                        .fontWeight(.semibold)
                    
                    Text(article.title)
                        .font(.largeTitle.bold())
                        .multilineTextAlignment(.leading)
                }
                .foregroundStyle(.white)
                .padding()
                
                ActionButton(label: "Close", systemImage: "xmark.circle.fill", action: closeAction)
                    .foregroundStyle(.white)
                    .scaleEffect(style == .detail ? 1 : 0.5)
                    .opacity(style == .detail ? 1 : 0)
                    .hSpacing(.trailing)
            }
        }
        .background {
            RoundedRectangle(cornerRadius: 15, style: .continuous)
                .fill(.thickMaterial)
        }
    }
}

#Preview {
    Group {
        ArticleCard(article: .article1, presenting: false)
            .previewDisplayName("Thumbnail")
        
        ArticleCard(article: .article1, presenting: true)
            .previewDisplayName("Detail")
    }
}
