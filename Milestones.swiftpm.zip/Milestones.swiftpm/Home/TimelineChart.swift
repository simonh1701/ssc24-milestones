import SwiftUI
import Charts

struct TimelineChart: View {
    @Environment(\.colorScheme) var colorScheme
    
    var headerTitle: String
    var milestones: [Milestone]
    var chartXScaleRangeStart: Date
    var chartXScaleRangeEnd: Date
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(headerTitle)
                .font(.title)
            
            ScrollView(.horizontal) { 
                    Chart {
                        ForEach(milestones, id: \.self) { milestone in
                            Plot {
                                BarMark(
                                    xStart: .value("Start Date", milestone.startDate),
                                    xEnd: .value("End Date", milestone.endDate),
                                    y: .value("Milestone", milestone.category?.name ?? "No category")
                                )
                                .clipShape(RoundedRectangle(cornerRadius: 5, style: .continuous))
                                .foregroundStyle(by: .value("Status", milestone.status.name))
                            }
                        }
                        
                        RuleMark(x: .value("Now", Date.now))
                            .foregroundStyle(colorScheme == .dark ? .white : .black)
                    }
                    .frame(width: 1800, height: 200)
                    .chartXScale(domain: chartXScaleRangeStart...chartXScaleRangeEnd)
                    .chartYScale(domain: [
                        Milestone.Category.academic.name, 
                        Milestone.Category.personal.name,
                        Milestone.Category.professional.name, 
                        "No category"])
                    .chartForegroundStyleScale([
                        "On Track": Color(0x009966).gradient.opacity(0.5), 
                        "Behind Schedule": Color(0xFD5D00).gradient.opacity(0.5), 
                        "Succeeded": Color(0x00A0FD).gradient.opacity(0.5), 
                        "Failed": Color(0xB143AE).gradient.opacity(0.5)
                    ])
            }
            .scrollIndicators(.hidden)
        }
    }
}
