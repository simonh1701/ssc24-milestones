import SwiftData
import SwiftUI

struct SlidingCardStackView<Item: Identifiable, ItemView: View>: View {
    init(index: Binding<Int>, cards: [Item], @ViewBuilder viewForItem: @escaping (Int, Item) -> ItemView) {
        self._nextIndex = index
        self.cards = cards
        self.viewForItem = viewForItem
    }
    
    @Binding var nextIndex: Int
    @State private var currentIndex: Int = 0
    @State private var offset : CGFloat = 0
    @State private var isDragging = false
    let cards: [Item]
    let viewForItem: (Int, Item) -> ItemView
    
    var body: some View {
        if cards.isEmpty {
            VStack {
                Text("No milestones")
                    .font(.title2)
                    .bold()
                    .hSpacing(.leading)
                Text("There a currently no active milestones!")
                    .font(.callout)
                    .hSpacing(.leading)
                Spacer()
            }
        } else {
            GeometryReader { geometry in
                ZStack {
                    ForEach(Array(cards.enumerated()).reversed(), id:\.element.id) { index, card in
                        viewForItem(index, card)
                            .scaleEffect(index == currentIndex ? 1.0 : 0.9)
                            .frame(height: geometry.size.height)
                            .offset(x: CGFloat(index - currentIndex) * ((index < currentIndex) ? (geometry.size.width * 0.2) : (geometry.size.width * 0.18)))
                            .offset(CGSize(width: (index <= currentIndex) ? self.offset * (0.2) : 0, height: 0))
                            .zIndex(Double((index < currentIndex) ? index : (index > currentIndex) ? currentIndex - index : cards.count))
                            .onTapGesture {
                                if index != currentIndex {
                                    nextIndex = index
                                }
                            }
                    }
                }
                .hSpacing(.leading)
                .gesture(
                    DragGesture()
                        .onChanged { val in
                            isDragging = true
                            
                            withAnimation(.spring) {
                                self.offset = val.translation.width
                            }
                        }
                        .onEnded { value in
                            withAnimation(.spring){
                                self.offset = 0
                            }
                            
                            isDragging = false
                            
                            let cardWidth = geometry.size.width * 0.3
                            let offset = value.translation.width / cardWidth
                            
                            if value.translation.width < -offset {
                                nextIndex = min(currentIndex + 1, cards.count - 1)
                            } else if value.translation.width > offset {
                                nextIndex = max(currentIndex - 1, 0)
                            }
                        }
                )
            }
            .onChange(of: nextIndex) { oldValue, newValue in
                withAnimation(.spring){
                    self.currentIndex = newValue
                }
            }
        }
    }
}

struct SlidingCardStackPreviewView: View {
    @Query private var milestones: [Milestone]
    @State var index : Int = 0
    
    var body: some View {
        SlidingCardStackView(index: $index, cards: milestones) { index, item in
            MilestoneCardView(milestone: item)
                .frame(width: 275, height: 155)
        }
    }
}

#Preview {
    do {
        let previewer = try Previewer()
        
        return SlidingCardStackPreviewView()
            .modelContainer(previewer.container)
            .frame(height: 155)
    } catch {
        return Text("Failed to create preview: \(error.localizedDescription)")
    }
}
