import SwiftUI
import SwiftData

struct HomeNavigationStack: View {
    @State private var path = [Milestone]()
    
    var body: some View {
        NavigationStack(path: $path) { 
            HomeView()
                .navigationTitle("Home")
                .toolbarBackground(.automatic, for: .navigationBar)
                .navigationDestination(for: Milestone.self) { milestone in
                    EditMilestoneView(milestone: milestone, navigationPath: $path)
                }
        }
    }
}
