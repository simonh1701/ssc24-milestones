import SwiftUI
import SwiftData

struct ShareMilestoneView: View {
    @Query private var milestones: [Milestone]
    
    @Environment(\.colorScheme) var colorScheme
    
    @State private var isTimePeriodVisible = true
    @State private var isWaterMarkVisible = true
    @State private var selectedMilestone: Milestone? = nil
    @State private var heading: String = ""
    @State private var text: String = ""
    
    var body: some View {
        Form {
            SelectMilestoneView(milestones: milestones, selectedMilestone: $selectedMilestone)
            
            Section {
                TextField("Heading", text: $heading)
                TextField("Text", text: $text)
            }  header: {
                Text("Tell the world about your milestone!")
            } footer: {
                Text("Tell the world where you have put your effort in and what your journey has taught you, no matter what the outcome was.")
            }
            
            Section {
                Toggle(
                    "Show time period",
                    isOn: $isTimePeriodVisible.animation(.default)
                )
                
                Toggle(
                    "Show milestones watermark",
                    isOn: $isWaterMarkVisible.animation(.default)
                )
            }
            if selectedMilestone != nil {
                Section("Preview") {
                    Image(uiImage: generateSnapshot())
                        .resizable()
                        .scaledToFit()
                }
                .listRowInsets(EdgeInsets())
            }
        }
        .navigationTitle("Share Milestone")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                ShareLink(
                    item: Image(uiImage: generateSnapshot()),
                    preview: SharePreview(
                        "Share your Milestone!",
                        image: Image(uiImage: generateSnapshot())
                    )
                )
                .disabled(selectedMilestone == nil)
            }
        }
        .tint(.accentColor)
    }
    
    @MainActor
    private func generateSnapshot() ->  UIImage  {
        guard let milestone = selectedMilestone else { return UIImage() }
        let imagePreview = ImagePreview(milestone: milestone, color: milestone.status.color, heading: heading, text: text, isTimePeriodVisible: isTimePeriodVisible, isWaterMarkVisible: isWaterMarkVisible)
            .frame(width: 500, height: 500)
        let renderer = ImageRenderer(content: imagePreview)
        renderer.scale = UIScreen.main.scale
        
        return renderer.uiImage ?? UIImage()
    }
}

#Preview {
    do {
        let previewer = try Previewer()
        
        return NavigationStack {
            ShareMilestoneView()
        }
        .modelContainer(previewer.container)
    } catch {
        return Text("Failed to create preview: \(error.localizedDescription)")
    }
}
