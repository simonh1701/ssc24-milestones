import SwiftUI

struct ImagePreview: View {
    var milestone: Milestone
    var color: Color = .gray
    var heading: String
    var text: String
    var isTimePeriodVisible = true
    var isWaterMarkVisible = true
    
    var body: some View {
        ZStack {
            Rectangle()
                .fill(color.gradient)
            
            VStack {
                HStack {
                    Spacer()
                    
                    Image(systemName: "laurel.leading")
                        .opacity(milestone.status == .success ? 1 : 0)
                    
                    VStack(spacing: 0) {
                        Text("Milestone")
                            .font(.system(size: 40, weight: .black))
                        Text(milestone.status.name)
                            .font(.title2)
                    }
                    
                    Image(systemName: "laurel.trailing")
                        .opacity(milestone.status == .success ? 1 : 0)
                    
                    Spacer()
                }
                .font(.system(size: 80, weight: .black))
                .foregroundStyle(color.gradient)
                .padding(.top, 8)
                
                VStack(spacing: 8) {
                    Text(milestone.title)
                        .font(.title2)
                        .fontWeight(.heavy)
                    
                    if isTimePeriodVisible {
                        Text("\(milestone.persistedStartDate.formatted(date: .numeric, time: .omitted)) - \(milestone.persistedEndDate.formatted(date: .numeric, time: .omitted))")
                            .font(.subheadline)
                        
                    }
                    
                    Text(heading)
                        .font(.title3)
                        .fontWeight(.bold)
                        .padding(.top)
                    
                    Text(text)
                        .fontWeight(.medium)
                        .italic()
                    
                    Spacer()
                    
                    if isWaterMarkVisible {
                        Text("Progress tracked with **Milestones** by Simon Hohenwarter.")
                            .fontWeight(.thin)
                    }
                }
                .multilineTextAlignment(.center)
                .padding([.horizontal, .bottom], 16)
                
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.thinMaterial)
            .cornerRadius(16)
            .padding()
        }
        .aspectRatio(1, contentMode: .fill)
    }
}

#Preview {
    do {
        let previewer = try Previewer()
        
        previewer.milestone.status = .success
        
        return ImagePreview(milestone: previewer.milestone, color: previewer.milestone.status.color, heading: "Heading", text: "Text", isTimePeriodVisible: true, isWaterMarkVisible: true)
            .preferredColorScheme(.light)
            .frame(width: 500, height: 500)
            .modelContainer(previewer.container)
    } catch {
        return Text("Failed to create preview: \(error.localizedDescription)")
    }
}
