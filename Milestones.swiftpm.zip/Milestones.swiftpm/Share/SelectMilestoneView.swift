import SwiftUI

struct SelectMilestoneView: View {
    var milestones: [Milestone]
    @Binding var selectedMilestone: Milestone?
    
    var body: some View {
        Section {
            Picker("Select a milestone", selection: $selectedMilestone) {
                Text("None")
                    .tag(Optional<Milestone>.none)
                
                if milestones.isEmpty == false {
                    Divider()
                    
                    ForEach(milestones.filter { milestone in 
                        milestone.status == Milestone.Status.fail || milestone.status == Milestone.Status.success
                    }) { milestone in
                        Text(milestone.title.isEmpty ? "New milestone" : milestone.title)
                            .tag(Optional(milestone))
                    }
                }
            }
        }
    }
}
